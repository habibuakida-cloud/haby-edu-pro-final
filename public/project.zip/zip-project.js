import AdmZip from 'adm-zip';
import path from 'path';
import fs from 'fs';

console.log('Zipping project workspace...');

const zip = new AdmZip();

function addFilesRecursively(localPath, zipPath = '') {
  if (!fs.existsSync(localPath)) return;
  const items = fs.readdirSync(localPath);
  
  items.forEach(item => {
    const fullPath = path.join(localPath, item);
    const stat = fs.statSync(fullPath);
    
    // Ignore heavy / temporary files and standard exclusions
    if (
      item === 'node_modules' ||
      item === '.git' ||
      item === 'dist' ||
      item === 'project.zip' ||
      item === 'project.tar.gz' ||
      item === '.env'
    ) {
      return;
    }
    
    if (stat.isDirectory()) {
      addFilesRecursively(fullPath, path.join(zipPath, item));
    } else {
      zip.addLocalFile(fullPath, zipPath);
    }
  });
}

try {
  addFilesRecursively('.');
  
  // Ensure the public directory exists
  if (!fs.existsSync('public')) {
    fs.mkdirSync('public');
  }
  
  zip.writeZip('public/project.zip');
  console.log('Success! Project successfully zipped to public/project.zip');
} catch (err) {
  console.error('Error zipping project:', err);
  process.exit(1);
}
